// Write your Javascript code.
function ThisFunction(id, person) {
    
}
console.log('');

// This function rocks

function name(){
    return value
}