var msg = "Don't judge this prg by its size";
console.log(msg);
